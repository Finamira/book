<form name="uploadMed" method="POST" action="brouillon.php"  enctype="multipart/form-data">
					<input type="file" name="file">
					<input type="hidden" name="MAX_FILE_SIZE" value="30000" />
					<input type="submit" value="envoyer">
				</form>