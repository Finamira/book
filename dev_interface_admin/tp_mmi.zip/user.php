<?php include_once "includes/function.php" ?>
	<?php
		//traitement du formulaire.
			if($_POST){
				if(isset($_POST['addUser'])){
				$login = $_POST['login'];
				$password = $_POST['password'];
				$confirm = $_POST['confirm'];
				$mail = $_POST['mail'];
				$role = 3;
				if($password == $confirm){
					$add = addUser($login,$password,$mail,$role);
					echo "vous êtes enregistrés";
					}
				else{
					echo "mdp incorrect";
					}
				}
				elseif(isset($_POST['deleteUser'])){
					$del = $_POST['delUsr'];
					delUser($del);
					}
				}
		?>
		<form name="insertUser" method="POST" action="user.php">
					<label for="log">Login :</label>
					<input type="text" name="login" id="log"> <br>					
					<label for="passwd">Mot de passe :</label>
					<input type="password" name="password" id="passwd"> <br>
					<label for="confirm">Confirmation :</label>
					<input type="password" name="confirm" id="confirm"> <br>
					<label for="mail">e-mail :</label>
					<input type="text" name="mail" id="mail"> <br>
					<input type="submit" name="addUser" value="envoyer">
		</form>
		<form name="delUser" method="POST" action="user.php">
					<select name="delUsr">
					<?php $tri = selectAllUser();
					while ($tab = mysqli_fetch_array($tri)) { 
						echo '<option value="';
						echo $tab['id_utilisateur'];
						echo '">';
						echo $tab['login'];
						echo "</option>";
					} ?>
					</select>
					<input type="submit" name ="deleteUser" id="supprimer" value="supprimer">
				</form>