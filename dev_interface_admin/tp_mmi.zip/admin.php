<?php /*le fichier admin concerne toutes les modifications pouvant être apportées par un utilisateur en fonction de son rôle. L'accessibilité aux fonctions est limitées en fonction du rôle via des conditions. 
*/?>
<?php include_once "includes/function.php";
	$user = ConnexionUser($login, $password); 
	?>
	<?php
		//gestion des catégories accès seulement via l'administrateur
			if($_POST){
				if(isset($_POST['add'])){
					$nom = $_POST['nom'];
					echo $nom; 
					echo " a été insérée";
					addCat($nom);
				}
				elseif(isset($_POST['delete'])){
					$del = $_POST['del'];
					echo $del;
					echo " a été supprimé";
					deleteCat($del);
					}
				elseif(isset($_POST['update'])){
					$id = $_POST['upd'];
					$nom = $_POST['nom'];
					updateCat($id, $nom);
				}
			?>
			<?php
				$log = selectOneUser($user[0]);
				echo $log[0];
				if($log[1] == 1){ ?>
				<form name="addcat" method="POST" action="admin.php">
					<label for="ajout">Créer une catégorie</label>
					<input type="text" name="nom" id="ajout">
					<input type="submit" name="add" id="send" value="ajouter">
				</form>
  				<form name="del-cat" method="POST" action="admin.php">
					<select name="del">
					<?php $tri = selectAllCategories(); 
					while ($tab = mysqli_fetch_array($tri)) { 
						echo '<option value="';
						echo $tab['id_categorie'];
						echo '">';
						echo $tab['nom'];
						echo "</option>";
					} ?>
					</select>
					<input type="submit" name ="delete" id="supprimer" value="supprimer">
				</form>
   				<form name="upd-cat" method="POST" action = "admin.php">
				<select name="upd">
				<?php $tri = selectAllCategories(); 
				while ($tab = mysqli_fetch_array($tri)) { 
					echo '<option value="';
					echo $tab['id_categorie'];
					echo '">';
					echo $tab['nom'];
					echo "</option>";
				} ?>
				</select>
				<label for="modif">Rennomer la catégorie</label>
				<input type="text" name="nom" id="modifier">
				<input type="submit" name="update" value="modifier" id="mod">
				</form>
				<table>
        		<tbody>
        			<?php $tri = SelectAllART();
					while($tab= mysqli_fetch_array($tri)){ ?>
					<tr>
						<td><?php echo $tab['title']; ?></td>
						<td><?php echo $tab['date']; ?></td>
					</tr>
				<?php } ?>
        		</tbody>
        	</table>
			<?php }} ?>