<?php include_once "includes/function.php" ?>
	<?php
		//traitement du formulaire.
			if($_POST){
				$login = $_POST['login'];
				$password = $_POST['password'];
				$user = ConnexionUser($login, $password);
				if($user){
					$log = selectOneUser($user[0]);
					include_once "admin.php";
					include_once "menu.php";
				}} ?>
	<form name="connect" method="POST" action="connexion.php">
					<input type="text" name="login">
					<input type="password" name="password">
					<input type="submit" value="envoyer">
	</form>