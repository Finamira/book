<!DOCTYPE html>
<!--fichier html/php créé par Pierre Alberti et Yao Chen-->
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="keywords" content="Pierre, Alberti, système, partide, jdr">
	<meta name="Partide" content="système de jeu inventé par pierre Alberti">
	<title>Intégration web S3</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="js/main.js"></script>
</head>

<body>
<nav>
<?php
	require_once "menu.php";
?>
	</nav>
	<?php
	require_once "connexion.php";
	?>
</body>

</html>