<html>
	<body>
		<?php include_once "includes/function.php" ?>
		<?php 
			$article = $_GET['idArticle'];
			$ART = affichageART($article);
			$MED = selectMedia($article)?>
			<?php
			if($_POST){
				if(isset($_POST['update'])){
				$title = $_POST['titre'];
				$text = $_POST['text'];
				updateART($article, $title, $text);
				}
			?>
			<h2><?php echo $ART['title']; ?></h2>
			<img src="<?php echo $MED['chemin'] ?>" alt="<?php echo $MED['id-medias'] ?>">
			<p><?php echo $ART['date']; ?></p>
			<p><?php echo $ART['texte']; ?></p>
			<?php }
			else{?>
			
			<h2><?php echo $ART['title']; ?></h2>
			<img src="<?php echo $MED['chemin'] ?>" alt="<?php echo $MED['id-medias'] ?>">
			<p><?php echo $ART['date']; ?></p>
			<p><?php echo $ART['texte']; ?></p>
			
			<div id="updART">
			<form name="updArt" method="POST" action = "article.php?idArticle=<?php echo $article; ?>">
			<label for="ajoutT">Titre</label>
			<input type="text" name="titre" id="ajoutTi">
			<label for="ajoutTe">Texte</label>
			<textarea name="text" id="ajoutTe" rows="12" cols="70"></textarea>
			<input type="submit" name="update" value="modifier" id="mod">
			</form>
			</div>
			<?php } ?>
	</body>
</html>
